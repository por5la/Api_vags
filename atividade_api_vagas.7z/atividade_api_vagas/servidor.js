const express = require('express')
const port = 3000

const sequelize = require('./database.js')
async function sincronizar() {
    try {
        await sequelize.sync();
        // await sequelize.sync({force: true});
    } catch (err) {
        console.log(erro)
    }
}

const router = require('./routes/Vagas')

const app = express()
app.use(express.json())

app.use(router)
sincronizar()

app.listen(port, () => {
    console.log('Servidor rodando!')
})