
const { Sequelize } = require('sequelize')

const conexao = new Sequelize("postgresql://vinicius_porcincula:Z_A1iySdW7ErC4m9FASy0g@databasecluster-2809.j77.aws-us-east-1.cockroachlabs.cloud:26257/defaultdb?sslmode=verify-full")


// try {
//     await conexao.authenticate()
//     console.log('Conectado com sucesso')
// } catch (error) {
//     console.error('Erro ao conectar', error)
// }

module.exports = conexao
