const database = require('../database.js')
const Vagas = require('../models/Vagas.js')

const listarVagas = async (req, res) => {
    const resultado = await Vagas.findAll()
    res.status(200).send(resultado)
}


const categoria = async (req, res) => {
    const { id } = req.params
    const resultado = await Vagas.findAll({ where: { id } })
    res.status(200).send(resultado)
}


const listarCargo = async (req, res) => {
    try{
        const { cargo } = req.params
        const resultado = await Vagas.findOne({ where: { cargo: cargo } })
        console.log(resultado)
        res.status(200).send(resultado)
    } catch(e){
        console.log(e)
    }
}


const listarCidade = async (req, res) => {
    const { cidade } = req.params
    const resultado = await Vagas.findAll({ where: { cidade } })
    res.status(200).send(resultado)
}


const cadastrarVaga = async (req, res) => {
    const { titulo, descricao, cargo, cidade, salario } = req.body
    if (!titulo || !descricao || !cargo || !cidade || !salario) {
        return res.status(404).send({ mensagem: "Esta faltando as informações" })
    }

    const resultado = await Vagas.create({ titulo, descricao, cargo, cidade, salario })

    res.status(201).send(resultado)
}


const alterarId = async (req, res) => {
    const id = req.params.id
    const { titulo, descricao, cargo, cidade, salario  } = req.body
    if (!titulo || !descricao || !cargo || !cidade || !salario) {
        return res.status(404).send({ mensagem: "As informações estão incompletas" })
    }
    const resultado = await Vagas.update({ titulo, descricao, cargo, cidade, salario }, { where: { id } })
    res.status(200).send(resultado)
}


const deletar = async (req, res) => {
    const {id} = req.params
    if (!id) {
        return res.status(404).send({ mensagem: "As informações estão incompletas" })
    }

    await Vagas.destroy({ where: { id } })
    res.status(200).send({ mensagem: 'Vaga apagada com sucesso' })
}


module.exports = { listarVagas, categoria, cadastrarVaga, alterarId, deletar, listarCargo, listarCidade } 