const sequelize = require('../database.js')
const { Sequelize, DataTypes } = require('sequelize');

const Vagas = sequelize.define('Vagas', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    titulo: {
        type: DataTypes.STRING
    },
    descricao: {
        type: DataTypes.STRING
    },
    cargo: {
        type: DataTypes.STRING
    },
    cidade: {
        type: DataTypes.STRING
    },
    salario: {
        type: DataTypes.DECIMAL
    },
}, {
    createdAt: false, updatedAt: false, tableName: 'vagas'
})


module.exports = Vagas;