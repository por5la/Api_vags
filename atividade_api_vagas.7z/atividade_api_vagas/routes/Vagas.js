const express = require('express')
const router = express.Router()
const controller = require('../controllers/Vagas')

router.get('/vagas', controller.listarVagas)
router.get('/vagas/:id', controller.categoria)
router.get('/cargo/:cargo', controller.listarCargo)
router.get('/localizacao/:cidade', controller.listarCidade)
router.post('/vagas', controller.cadastrarVaga)
router.put('/vagas/:id', controller.alterarId)
router.delete('/vagas/:id', controller.deletar)

module.exports = router